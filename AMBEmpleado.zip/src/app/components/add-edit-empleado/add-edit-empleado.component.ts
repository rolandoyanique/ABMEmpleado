import { Component } from '@angular/core';

@Component({
  selector: 'app-add-edit-empleado',
  standalone: true,
  imports: [],
  templateUrl: './add-edit-empleado.component.html',
  styleUrl: './add-edit-empleado.component.css'
})
export class AddEditEmpleadoComponent {

}
