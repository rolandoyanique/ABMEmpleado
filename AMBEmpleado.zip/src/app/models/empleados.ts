export class Empleado{
    nombreCompleto!:string;
    telefono!:number;
    correo!:string;
    fechaIngreso!:Date;
    estadoCivil!:string;
    sexo!:string;
}